var express = require('express');
var router = express.Router();


// var test = require('../models/test');
/* GET users listing. */
router.get('/', function(req, res, next) {
  // test.find(function(err,doc){
  //   // console.log(doc);

  //   res.send(doc);
  // });
});

module.exports = router;
